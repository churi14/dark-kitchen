// app/admin/layout.tsx — Layout del panel de administración
// Sidebar con navegación entre pedidos, menú, cocina
import Link from 'next/link'
import LogoutButton from '@/components/admin/LogoutButton'

const NAV = [
  { href: '/admin/pedidos', label: 'Pedidos',    icon: '📋' },
  { href: '/admin/cocina',  label: 'Cocina',     icon: '🍳' },
  { href: '/admin/menu',    label: 'Menú',       icon: '🍽️' },
]

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-[var(--bg)]">

      {/* Sidebar (desktop) */}
      <aside className="hidden md:flex flex-col w-56 bg-[var(--surface)] border-r border-[var(--border)] py-6 px-3 flex-shrink-0">
        <div className="px-3 mb-6">
          <p className="font-display text-[16px] font-extrabold text-[var(--text)]">Dark Kitchen</p>
          <p className="text-[11px] text-[var(--text-muted)] mt-0.5">Panel de administración</p>
        </div>
        <nav className="flex flex-col gap-1 flex-1">
          {NAV.map(item => (
            <Link key={item.href} href={item.href}
              className="flex items-center gap-2.5 px-3 py-2.5 rounded-[8px] text-[13px] font-semibold
                         text-[var(--text-muted)] hover:text-[var(--text)] hover:bg-[var(--surface-2)]
                         transition-colors">
              <span>{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="border-t border-[var(--border)] pt-2">
          <LogoutButton />
        </div>
      </aside>

      {/* Contenido */}
      <main className="flex-1 overflow-auto">{children}</main>

      {/* Bottom nav (mobile) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-[var(--surface)] border-t border-[var(--border)]
                      flex items-center justify-around px-2 py-2 z-50">
        {NAV.map(item => (
          <Link key={item.href} href={item.href}
            className="flex flex-col items-center gap-0.5 px-4 py-1 text-[var(--text-muted)] hover:text-[var(--text)]">
            <span className="text-xl">{item.icon}</span>
            <span className="text-[10px] font-semibold">{item.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  )
}